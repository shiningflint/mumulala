## Installation
`yarn install` under this directory

## Start development server
`yarn server`

## Building for production
`yarn build`

## Color palette
```
#37123C
#71677C
#A99F96
#DDA77B
#945D5E
```
