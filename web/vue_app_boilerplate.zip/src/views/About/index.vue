<template>
  <div class="about">
    This is the about page
  </div>
</template>

<style lang="scss" scoped>
.about {
  color: red;
}
</style>
